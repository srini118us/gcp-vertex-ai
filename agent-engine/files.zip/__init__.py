"""
Stock Agent Package
Lab 04: Vertex AI Agent Engine

This package contains an ADK agent for stock market analysis.
"""

from .agent import agent

__all__ = ["agent"]
