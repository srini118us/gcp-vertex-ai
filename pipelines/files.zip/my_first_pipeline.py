"""
Lab 05: Your First Vertex AI Pipeline
GCP Vertex AI Learning Path

This demonstrates:
1. Pipeline structure with Kubeflow SDK
2. Components (steps)
3. Data flow between components
4. Compiling and running pipelines

NO ML TRAINING = Minimal cost (just compute time ~$1-2)
"""

from kfp import dsl
from kfp.dsl import component, Output, Input, Artifact, Metrics
from kfp import compiler


# ============================================
# Component 1: Load Data
# ============================================
@component(
    base_image="python:3.11-slim",
    packages_to_install=["pandas"]
)
def load_data(
    num_samples: int,
    output_data: Output[Artifact]
) -> None:
    """Load or generate sample data."""
    import pandas as pd
    import json
    
    # Generate sample data (simulating loading from source)
    data = {
        "id": list(range(1, num_samples + 1)),
        "feature_1": [i * 1.5 for i in range(1, num_samples + 1)],
        "feature_2": [i * 2.0 for i in range(1, num_samples + 1)],
        "target": [i % 2 for i in range(1, num_samples + 1)]  # Binary classification
    }
    
    df = pd.DataFrame(data)
    
    # Save to artifact
    df.to_csv(output_data.path, index=False)
    
    # Log metadata
    output_data.metadata["num_rows"] = len(df)
    output_data.metadata["columns"] = list(df.columns)
    
    print(f"✅ Loaded {len(df)} samples with columns: {list(df.columns)}")


# ============================================
# Component 2: Process Data
# ============================================
@component(
    base_image="python:3.11-slim",
    packages_to_install=["pandas", "scikit-learn"]
)
def process_data(
    input_data: Input[Artifact],
    train_data: Output[Artifact],
    test_data: Output[Artifact],
    test_size: float = 0.2
) -> None:
    """Process and split data into train/test sets."""
    import pandas as pd
    from sklearn.model_selection import train_test_split
    
    # Load data from previous step
    df = pd.read_csv(input_data.path)
    
    # Simple preprocessing
    df["feature_1_normalized"] = df["feature_1"] / df["feature_1"].max()
    df["feature_2_normalized"] = df["feature_2"] / df["feature_2"].max()
    
    # Split data
    train_df, test_df = train_test_split(df, test_size=test_size, random_state=42)
    
    # Save artifacts
    train_df.to_csv(train_data.path, index=False)
    test_df.to_csv(test_data.path, index=False)
    
    # Log metadata
    train_data.metadata["num_rows"] = len(train_df)
    test_data.metadata["num_rows"] = len(test_df)
    
    print(f"✅ Split data: {len(train_df)} train, {len(test_df)} test")


# ============================================
# Component 3: Train Simple Model
# ============================================
@component(
    base_image="python:3.11-slim",
    packages_to_install=["pandas", "scikit-learn", "joblib"]
)
def train_model(
    train_data: Input[Artifact],
    model_artifact: Output[Artifact]
) -> None:
    """Train a simple model (LogisticRegression - fast, free!)."""
    import pandas as pd
    from sklearn.linear_model import LogisticRegression
    import joblib
    
    # Load training data
    df = pd.read_csv(train_data.path)
    
    X = df[["feature_1_normalized", "feature_2_normalized"]]
    y = df["target"]
    
    # Train simple model (fast!)
    model = LogisticRegression(max_iter=100)
    model.fit(X, y)
    
    # Save model
    joblib.dump(model, model_artifact.path)
    
    model_artifact.metadata["model_type"] = "LogisticRegression"
    model_artifact.metadata["features"] = ["feature_1_normalized", "feature_2_normalized"]
    
    print(f"✅ Model trained and saved")


# ============================================
# Component 4: Evaluate Model
# ============================================
@component(
    base_image="python:3.11-slim",
    packages_to_install=["pandas", "scikit-learn", "joblib"]
)
def evaluate_model(
    model_artifact: Input[Artifact],
    test_data: Input[Artifact],
    metrics: Output[Metrics]
) -> None:
    """Evaluate model and log metrics."""
    import pandas as pd
    from sklearn.metrics import accuracy_score, precision_score, recall_score
    import joblib
    
    # Load model and test data
    model = joblib.load(model_artifact.path)
    df = pd.read_csv(test_data.path)
    
    X_test = df[["feature_1_normalized", "feature_2_normalized"]]
    y_test = df["target"]
    
    # Predict
    y_pred = model.predict(X_test)
    
    # Calculate metrics
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    
    # Log metrics (will appear in Vertex AI UI!)
    metrics.log_metric("accuracy", accuracy)
    metrics.log_metric("precision", precision)
    metrics.log_metric("recall", recall)
    
    print(f"✅ Evaluation complete:")
    print(f"   Accuracy:  {accuracy:.4f}")
    print(f"   Precision: {precision:.4f}")
    print(f"   Recall:    {recall:.4f}")


# ============================================
# Define Pipeline
# ============================================
@dsl.pipeline(
    name="my-first-ml-pipeline",
    description="A simple ML pipeline demonstrating Vertex AI Pipelines"
)
def my_first_pipeline(
    num_samples: int = 100,
    test_size: float = 0.2
):
    """
    Pipeline flow:
    Load Data → Process Data → Train Model → Evaluate
    """
    
    # Step 1: Load data
    load_task = load_data(num_samples=num_samples)
    
    # Step 2: Process data (depends on Step 1)
    process_task = process_data(
        input_data=load_task.outputs["output_data"],
        test_size=test_size
    )
    
    # Step 3: Train model (depends on Step 2)
    train_task = train_model(
        train_data=process_task.outputs["train_data"]
    )
    
    # Step 4: Evaluate (depends on Steps 2 & 3)
    evaluate_task = evaluate_model(
        model_artifact=train_task.outputs["model_artifact"],
        test_data=process_task.outputs["test_data"]
    )


# ============================================
# Compile Pipeline
# ============================================
if __name__ == "__main__":
    # Compile to JSON (Vertex AI format)
    compiler.Compiler().compile(
        pipeline_func=my_first_pipeline,
        package_path="my_first_pipeline.json"
    )
    
    print("="*60)
    print("✅ Pipeline compiled successfully!")
    print("   Output: my_first_pipeline.json")
    print("="*60)
    print("\nNext steps:")
    print("1. Upload to Vertex AI: Console → Pipelines → Upload")
    print("2. Or run with Python (see run_pipeline.py)")
    print("="*60)
