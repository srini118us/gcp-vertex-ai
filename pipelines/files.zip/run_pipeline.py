"""
Run Pipeline on Vertex AI

This script submits the compiled pipeline to Vertex AI Pipelines.

COST ESTIMATE: ~$1-2 (just compute time, no expensive training)
"""

from google.cloud import aiplatform

# Configuration
PROJECT_ID = "genai-2222026"
REGION = "us-central1"
PIPELINE_ROOT = f"gs://sap-docs-genai-2222026/pipeline-runs"  # Your bucket

def run_pipeline():
    """Submit pipeline to Vertex AI."""
    
    # Initialize Vertex AI
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION
    )
    
    # Create pipeline job
    job = aiplatform.PipelineJob(
        display_name="my-first-pipeline-run",
        template_path="my_first_pipeline.json",  # Compiled pipeline
        pipeline_root=PIPELINE_ROOT,
        parameter_values={
            "num_samples": 100,
            "test_size": 0.2
        }
    )
    
    # Submit the job
    print("🚀 Submitting pipeline to Vertex AI...")
    print(f"   Project: {PROJECT_ID}")
    print(f"   Region: {REGION}")
    print(f"   Pipeline Root: {PIPELINE_ROOT}")
    
    job.submit()
    
    print("\n✅ Pipeline submitted!")
    print(f"   Job Name: {job.display_name}")
    print(f"   View in Console: https://console.cloud.google.com/vertex-ai/pipelines/runs?project={PROJECT_ID}")


if __name__ == "__main__":
    run_pipeline()
