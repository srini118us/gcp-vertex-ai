"""
MCP_SERVERS/SERVICENOW/SERVICENOW_TOOLS.PY
==========================================
ServiceNow MCP Tools for Incident Management

This module provides tools for:
- Creating incidents (INC)
- Searching incidents
- Getting incident details
- Creating change requests (CHG)

Supports both REAL API calls and MOCK mode for development.
"""

import json
import requests
from typing import Dict, Any, Optional, List
from datetime import datetime
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from config.settings import servicenow_config, mock_config

# =============================================================================
# MOCK DATA (Used when mock_config.use_mock_servicenow = True)
# =============================================================================

MOCK_INCIDENTS = [
    {
        "number": "INC0011987",
        "short_description": "Joule authentication failure - PROD",
        "description": "Users unable to authenticate to Joule. IAS trust configuration suspected.",
        "priority": "2",
        "state": "2",  # In Progress
        "category": "SAP",
        "subcategory": "Joule",
        "assignment_group": "SAP Basis Team",
        "assigned_to": "John Smith",
        "sys_created_on": "2026-04-05 10:30:00",
        "sys_id": "abc123def456"
    },
    {
        "number": "INC0011456",
        "short_description": "BDC sync failing with Datasphere",
        "description": "Business Data Cloud synchronization failing. Connection timeout errors.",
        "priority": "3",
        "state": "6",  # Resolved
        "category": "SAP",
        "subcategory": "BDC",
        "assignment_group": "SAP Basis Team",
        "assigned_to": "Jane Doe",
        "sys_created_on": "2026-03-28 14:15:00",
        "sys_id": "xyz789abc012"
    },
    {
        "number": "INC0010234",
        "short_description": "S/4HANA Fiori launchpad slow",
        "description": "Fiori apps taking 30+ seconds to load. Memory pressure suspected.",
        "priority": "3",
        "state": "6",  # Resolved
        "category": "SAP",
        "subcategory": "Performance",
        "assignment_group": "SAP Basis Team",
        "assigned_to": "Mike Johnson",
        "sys_created_on": "2026-03-15 09:00:00",
        "sys_id": "mno345pqr678"
    }
]

MOCK_INCIDENT_COUNTER = 12000  # For generating new INC numbers


# =============================================================================
# SERVICENOW API CLIENT
# =============================================================================

class ServiceNowClient:
    """Client for ServiceNow REST API operations."""
    
    def __init__(self):
        self.instance_url = servicenow_config.instance_url
        self.auth = (servicenow_config.username, servicenow_config.password)
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
    
    def _make_request(self, method: str, endpoint: str, data: dict = None) -> dict:
        """Make HTTP request to ServiceNow API."""
        url = f"{self.instance_url}{endpoint}"
        
        try:
            if method == "GET":
                response = requests.get(url, auth=self.auth, headers=self.headers)
            elif method == "POST":
                response = requests.post(url, auth=self.auth, headers=self.headers, json=data)
            elif method == "PUT":
                response = requests.put(url, auth=self.auth, headers=self.headers, json=data)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            return {"error": str(e), "status": "failed"}


# =============================================================================
# MCP TOOL FUNCTIONS
# =============================================================================

def create_incident(
    short_description: str,
    description: str,
    priority: str = "3",
    category: str = "SAP",
    subcategory: str = "Integration",
    caller_id: str = "System",
    assignment_group: str = None
) -> Dict[str, Any]:
    """
    Create a new incident in ServiceNow.
    
    Args:
        short_description: Brief title of the incident (max 160 chars)
        description: Detailed description of the issue
        priority: 1=Critical, 2=High, 3=Moderate, 4=Low
        category: Category (default: SAP)
        subcategory: Subcategory (default: Integration)
        caller_id: Who reported the incident
        assignment_group: Team to assign (default from config)
    
    Returns:
        Dictionary with incident number and details
    
    Example:
        create_incident(
            short_description="Joule not responding on PROD",
            description="Users report Joule assistant is not responding. Started 10:30 AM.",
            priority="2"
        )
    """
    global MOCK_INCIDENT_COUNTER
    
    if assignment_group is None:
        assignment_group = servicenow_config.default_assignment_group
    
    # Prepare incident data
    incident_data = {
        "short_description": short_description[:160],  # ServiceNow limit
        "description": description,
        "priority": priority,
        "category": category,
        "subcategory": subcategory,
        "caller_id": caller_id,
        "assignment_group": assignment_group,
        "impact": priority,  # Match impact to priority
        "urgency": priority
    }
    
    # MOCK MODE
    if mock_config.use_mock_servicenow:
        MOCK_INCIDENT_COUNTER += 1
        incident_number = f"INC00{MOCK_INCIDENT_COUNTER}"
        
        result = {
            "status": "success",
            "mode": "MOCK",
            "incident": {
                "number": incident_number,
                "sys_id": f"mock_{MOCK_INCIDENT_COUNTER}",
                "short_description": short_description,
                "priority": priority,
                "state": "1",  # New
                "assignment_group": assignment_group,
                "created_on": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "url": f"{servicenow_config.instance_url}/nav_to.do?uri=incident.do?sys_id=mock_{MOCK_INCIDENT_COUNTER}"
            },
            "message": f"Incident {incident_number} created successfully (MOCK MODE)"
        }
        return result
    
    # REAL API MODE
    client = ServiceNowClient()
    response = client._make_request("POST", "/api/now/table/incident", incident_data)
    
    if "error" in response:
        return {"status": "error", "message": response["error"]}
    
    result_data = response.get("result", {})
    return {
        "status": "success",
        "mode": "LIVE",
        "incident": {
            "number": result_data.get("number"),
            "sys_id": result_data.get("sys_id"),
            "short_description": result_data.get("short_description"),
            "priority": result_data.get("priority"),
            "state": result_data.get("state"),
            "assignment_group": result_data.get("assignment_group", {}).get("display_value"),
            "created_on": result_data.get("sys_created_on"),
            "url": f"{servicenow_config.instance_url}/nav_to.do?uri=incident.do?sys_id={result_data.get('sys_id')}"
        },
        "message": f"Incident {result_data.get('number')} created successfully"
    }


def search_incidents(
    query: str,
    limit: int = 5,
    category: str = "SAP"
) -> Dict[str, Any]:
    """
    Search for existing incidents matching a query.
    
    Args:
        query: Search term (searches short_description and description)
        limit: Maximum number of results (default: 5)
        category: Filter by category (default: SAP)
    
    Returns:
        Dictionary with matching incidents
    
    Example:
        search_incidents(query="Joule authentication")
    """
    
    # MOCK MODE
    if mock_config.use_mock_servicenow:
        query_lower = query.lower()
        matches = []
        
        for inc in MOCK_INCIDENTS:
            if (query_lower in inc["short_description"].lower() or 
                query_lower in inc["description"].lower()):
                matches.append(inc)
        
        return {
            "status": "success",
            "mode": "MOCK",
            "count": len(matches),
            "incidents": matches[:limit],
            "query": query
        }
    
    # REAL API MODE
    client = ServiceNowClient()
    
    # Build query string for ServiceNow
    encoded_query = (
        f"short_descriptionLIKE{query}^ORdescriptionLIKE{query}"
        f"^category={category}^ORDERBYDESCsys_created_on"
    )
    
    response = client._make_request(
        "GET", 
        f"/api/now/table/incident?sysparm_query={encoded_query}&sysparm_limit={limit}"
    )
    
    if "error" in response:
        return {"status": "error", "message": response["error"]}
    
    incidents = response.get("result", [])
    return {
        "status": "success",
        "mode": "LIVE",
        "count": len(incidents),
        "incidents": [
            {
                "number": inc.get("number"),
                "short_description": inc.get("short_description"),
                "priority": inc.get("priority"),
                "state": inc.get("state"),
                "created_on": inc.get("sys_created_on")
            }
            for inc in incidents
        ],
        "query": query
    }


def get_incident(incident_number: str) -> Dict[str, Any]:
    """
    Get details of a specific incident.
    
    Args:
        incident_number: The INC number (e.g., "INC0011987")
    
    Returns:
        Dictionary with full incident details
    
    Example:
        get_incident("INC0011987")
    """
    
    # MOCK MODE
    if mock_config.use_mock_servicenow:
        for inc in MOCK_INCIDENTS:
            if inc["number"] == incident_number:
                return {
                    "status": "success",
                    "mode": "MOCK",
                    "incident": inc
                }
        return {
            "status": "not_found",
            "mode": "MOCK",
            "message": f"Incident {incident_number} not found"
        }
    
    # REAL API MODE
    client = ServiceNowClient()
    response = client._make_request(
        "GET",
        f"/api/now/table/incident?sysparm_query=number={incident_number}"
    )
    
    if "error" in response:
        return {"status": "error", "message": response["error"]}
    
    incidents = response.get("result", [])
    if not incidents:
        return {"status": "not_found", "message": f"Incident {incident_number} not found"}
    
    return {
        "status": "success",
        "mode": "LIVE",
        "incident": incidents[0]
    }


def get_related_incidents(
    short_description: str,
    limit: int = 3
) -> Dict[str, Any]:
    """
    Find incidents similar to a given description.
    Useful for identifying recurring issues or patterns.
    
    Args:
        short_description: Description to match against
        limit: Maximum number of related incidents
    
    Returns:
        Dictionary with related incidents
    
    Example:
        get_related_incidents("Joule not working")
    """
    # Extract keywords from description
    keywords = [word for word in short_description.lower().split() 
                if len(word) > 3 and word not in ['with', 'that', 'this', 'from', 'have']]
    
    # Search for each keyword
    all_matches = []
    
    if mock_config.use_mock_servicenow:
        for inc in MOCK_INCIDENTS:
            score = sum(1 for kw in keywords 
                       if kw in inc["short_description"].lower() or kw in inc["description"].lower())
            if score > 0:
                all_matches.append({"incident": inc, "relevance_score": score})
        
        # Sort by relevance
        all_matches.sort(key=lambda x: x["relevance_score"], reverse=True)
        
        return {
            "status": "success",
            "mode": "MOCK",
            "count": len(all_matches[:limit]),
            "related_incidents": [m["incident"] for m in all_matches[:limit]],
            "keywords_matched": keywords
        }
    
    # For real mode, use the search function
    return search_incidents(query=" ".join(keywords[:2]), limit=limit)


# =============================================================================
# TEST FUNCTIONS
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("SERVICENOW MCP TOOLS - TEST")
    print("=" * 60)
    
    # Test 1: Create incident
    print("\n1. Creating incident...")
    result = create_incident(
        short_description="Joule not responding - PROD environment",
        description="Users report Joule assistant is not responding. Started around 10:30 AM IST.",
        priority="2"
    )
    print(json.dumps(result, indent=2))
    
    # Test 2: Search incidents
    print("\n2. Searching incidents...")
    result = search_incidents(query="Joule")
    print(json.dumps(result, indent=2))
    
    # Test 3: Get related incidents
    print("\n3. Finding related incidents...")
    result = get_related_incidents("Joule authentication failure")
    print(json.dumps(result, indent=2))
    
    print("\n" + "=" * 60)
    print("Tests completed!")
