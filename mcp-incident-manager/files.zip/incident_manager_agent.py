"""
ORCHESTRATOR/INCIDENT_MANAGER_AGENT.PY
======================================
SAP Incident Manager - MCP Orchestrator Agent

This agent orchestrates the incident management workflow:
1. User reports an issue
2. Agent searches SAP documentation for troubleshooting steps
3. Agent creates ServiceNow incident
4. Agent finds related past incidents
5. Agent posts notification to Teams with all context

Uses MCP (Model Context Protocol) pattern:
- Each external service has its own MCP server/tools
- Orchestrator agent decides which tools to call and when
- Results are synthesized into a coherent response
"""

import json
from typing import Dict, Any, List
from datetime import datetime

# Import MCP tools
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from mcp_servers.servicenow.servicenow_tools import (
    create_incident,
    search_incidents,
    get_related_incidents
)
from mcp_servers.teams.teams_tools import (
    post_incident_notification,
    post_simple_message
)
from mcp_servers.rag.sap_docs_tool import (
    search_sap_documentation,
    get_troubleshooting_steps
)
from config.settings import servicenow_config


# =============================================================================
# ORCHESTRATOR FUNCTIONS
# =============================================================================

def handle_incident_report(
    user_report: str,
    priority: str = "3",
    reporter_name: str = "User",
    auto_create_ticket: bool = True,
    auto_notify_teams: bool = True
) -> Dict[str, Any]:
    """
    Main orchestration function for handling incident reports.
    
    This function:
    1. Analyzes the user's report
    2. Searches SAP documentation for relevant troubleshooting
    3. Finds related past incidents
    4. Creates a ServiceNow incident (if auto_create_ticket=True)
    5. Posts notification to Teams (if auto_notify_teams=True)
    
    Args:
        user_report: Natural language description of the issue
        priority: Priority level (1=Critical, 2=High, 3=Moderate, 4=Low)
        reporter_name: Name of the person reporting
        auto_create_ticket: Whether to create ServiceNow ticket
        auto_notify_teams: Whether to post to Teams
    
    Returns:
        Dictionary with all actions taken and results
    
    Example:
        handle_incident_report(
            user_report="Joule is not working on PROD. Users can't access.",
            priority="2",
            reporter_name="John Smith"
        )
    """
    
    workflow_start = datetime.now()
    results = {
        "workflow": "incident_report",
        "started_at": workflow_start.isoformat(),
        "user_report": user_report,
        "priority": priority,
        "reporter": reporter_name,
        "steps": []
    }
    
    print("\n" + "=" * 70)
    print("🚀 SAP INCIDENT MANAGER - PROCESSING REPORT")
    print("=" * 70)
    print(f"Report: {user_report}")
    print(f"Priority: P{priority}")
    print(f"Reporter: {reporter_name}")
    print("-" * 70)
    
    # =========================================================================
    # STEP 1: Search SAP Documentation for Troubleshooting
    # =========================================================================
    print("\n📚 STEP 1: Searching SAP documentation...")
    
    rag_result = get_troubleshooting_steps(user_report)
    
    troubleshooting_text = None
    if rag_result["status"] == "success":
        troubleshooting_text = rag_result.get("response", "")[:800]
        print(f"   ✅ Found relevant documentation")
        print(f"   Preview: {troubleshooting_text[:200]}...")
    else:
        print(f"   ⚠️ No documentation found: {rag_result.get('message', 'Unknown error')}")
    
    results["steps"].append({
        "step": 1,
        "action": "search_sap_documentation",
        "status": rag_result["status"],
        "troubleshooting": troubleshooting_text
    })
    
    # =========================================================================
    # STEP 2: Find Related Past Incidents
    # =========================================================================
    print("\n🔍 STEP 2: Finding related incidents...")
    
    related_result = get_related_incidents(user_report)
    
    related_incident_numbers = []
    if related_result["status"] == "success" and related_result.get("count", 0) > 0:
        related_incident_numbers = [
            inc["number"] for inc in related_result.get("related_incidents", [])
        ]
        print(f"   ✅ Found {len(related_incident_numbers)} related incidents: {', '.join(related_incident_numbers)}")
    else:
        print(f"   ℹ️ No related incidents found")
    
    results["steps"].append({
        "step": 2,
        "action": "find_related_incidents",
        "status": related_result["status"],
        "related_incidents": related_incident_numbers
    })
    
    # =========================================================================
    # STEP 3: Create ServiceNow Incident
    # =========================================================================
    incident_number = None
    servicenow_url = None
    
    if auto_create_ticket:
        print("\n🎫 STEP 3: Creating ServiceNow incident...")
        
        # Build description with troubleshooting steps
        description = f"""Issue reported by: {reporter_name}

User Report:
{user_report}

"""
        if troubleshooting_text:
            description += f"""
Suggested Troubleshooting (from SAP Documentation):
{troubleshooting_text}
"""
        
        if related_incident_numbers:
            description += f"""
Related Past Incidents: {', '.join(related_incident_numbers)}
"""
        
        incident_result = create_incident(
            short_description=user_report[:160],  # ServiceNow limit
            description=description,
            priority=priority,
            category="SAP",
            subcategory="Integration",
            caller_id=reporter_name
        )
        
        if incident_result["status"] == "success":
            incident_data = incident_result.get("incident", {})
            incident_number = incident_data.get("number")
            servicenow_url = incident_data.get("url")
            print(f"   ✅ Created: {incident_number}")
            print(f"   URL: {servicenow_url}")
        else:
            print(f"   ❌ Failed to create incident: {incident_result.get('message')}")
        
        results["steps"].append({
            "step": 3,
            "action": "create_servicenow_incident",
            "status": incident_result["status"],
            "incident_number": incident_number,
            "url": servicenow_url
        })
    else:
        print("\n🎫 STEP 3: Skipped (auto_create_ticket=False)")
        results["steps"].append({
            "step": 3,
            "action": "create_servicenow_incident",
            "status": "skipped"
        })
    
    # =========================================================================
    # STEP 4: Post to Microsoft Teams
    # =========================================================================
    if auto_notify_teams:
        print("\n📣 STEP 4: Posting to Microsoft Teams...")
        
        teams_result = post_incident_notification(
            incident_number=incident_number or "PENDING",
            title=user_report[:160],
            priority=priority,
            description=user_report,
            troubleshooting=troubleshooting_text,
            related_incidents=related_incident_numbers if related_incident_numbers else None,
            servicenow_url=servicenow_url
        )
        
        if teams_result["status"] == "success":
            print(f"   ✅ Posted to #{teams_result.get('channel', 'unknown')}")
        else:
            print(f"   ❌ Failed: {teams_result.get('message')}")
        
        results["steps"].append({
            "step": 4,
            "action": "post_teams_notification",
            "status": teams_result["status"],
            "channel": teams_result.get("channel")
        })
    else:
        print("\n📣 STEP 4: Skipped (auto_notify_teams=False)")
        results["steps"].append({
            "step": 4,
            "action": "post_teams_notification",
            "status": "skipped"
        })
    
    # =========================================================================
    # SUMMARY
    # =========================================================================
    workflow_end = datetime.now()
    duration = (workflow_end - workflow_start).total_seconds()
    
    results["completed_at"] = workflow_end.isoformat()
    results["duration_seconds"] = duration
    results["incident_number"] = incident_number
    results["servicenow_url"] = servicenow_url
    
    print("\n" + "=" * 70)
    print("✅ WORKFLOW COMPLETE")
    print("=" * 70)
    print(f"Duration: {duration:.2f} seconds")
    print(f"Incident: {incident_number or 'Not created'}")
    if troubleshooting_text:
        print(f"Troubleshooting: Found relevant documentation")
    if related_incident_numbers:
        print(f"Related Issues: {', '.join(related_incident_numbers)}")
    print("=" * 70 + "\n")
    
    return results


def quick_search(query: str) -> Dict[str, Any]:
    """
    Quick search across all MCP sources.
    
    Args:
        query: Search query
    
    Returns:
        Combined results from documentation and incidents
    """
    
    results = {
        "query": query,
        "sources": {}
    }
    
    # Search documentation
    doc_results = search_sap_documentation(query)
    results["sources"]["sap_documentation"] = doc_results
    
    # Search incidents
    incident_results = search_incidents(query)
    results["sources"]["past_incidents"] = incident_results
    
    return results


# =============================================================================
# INTERACTIVE CLI
# =============================================================================

def interactive_mode():
    """Run the incident manager in interactive mode."""
    
    print("\n" + "=" * 70)
    print("🤖 SAP INCIDENT MANAGER - INTERACTIVE MODE")
    print("=" * 70)
    print("Commands:")
    print("  report <description>  - Report a new incident")
    print("  search <query>        - Search docs and incidents")
    print("  help                  - Show this help")
    print("  quit                  - Exit")
    print("=" * 70 + "\n")
    
    while True:
        try:
            user_input = input("You: ").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() in ["quit", "exit", "q"]:
                print("Goodbye!")
                break
            
            if user_input.lower() == "help":
                print("\nCommands:")
                print("  report <description>  - Report a new incident")
                print("  search <query>        - Search docs and incidents")
                print("  quit                  - Exit\n")
                continue
            
            if user_input.lower().startswith("report "):
                description = user_input[7:].strip()
                priority = input("Priority (1=Critical, 2=High, 3=Moderate, 4=Low) [3]: ").strip() or "3"
                reporter = input("Your name [User]: ").strip() or "User"
                
                handle_incident_report(
                    user_report=description,
                    priority=priority,
                    reporter_name=reporter
                )
                continue
            
            if user_input.lower().startswith("search "):
                query = user_input[7:].strip()
                result = quick_search(query)
                print(json.dumps(result, indent=2, default=str))
                continue
            
            # Default: treat as incident report
            print("\nTreating as incident report...")
            handle_incident_report(user_report=user_input)
            
        except KeyboardInterrupt:
            print("\nGoodbye!")
            break
        except Exception as e:
            print(f"Error: {e}")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="SAP Incident Manager")
    parser.add_argument("--interactive", "-i", action="store_true", help="Run in interactive mode")
    parser.add_argument("--report", "-r", type=str, help="Report an incident")
    parser.add_argument("--priority", "-p", type=str, default="3", help="Priority (1-4)")
    parser.add_argument("--demo", action="store_true", help="Run demo scenarios")
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_mode()
    elif args.report:
        handle_incident_report(
            user_report=args.report,
            priority=args.priority
        )
    elif args.demo:
        # Demo scenarios
        print("\n🎬 RUNNING DEMO SCENARIOS\n")
        
        # Scenario 1: Joule issue
        print("\n" + "=" * 70)
        print("SCENARIO 1: Joule Not Working")
        print("=" * 70)
        handle_incident_report(
            user_report="Joule is not responding in PROD environment. Users are unable to access the AI assistant.",
            priority="2",
            reporter_name="Demo User"
        )
        
        # Scenario 2: Authentication issue
        print("\n" + "=" * 70)
        print("SCENARIO 2: Authentication Failure")
        print("=" * 70)
        handle_incident_report(
            user_report="Users getting authentication errors when accessing SAP Fiori apps after IAS configuration change.",
            priority="2",
            reporter_name="Demo User"
        )
    else:
        # Default: show help
        parser.print_help()
