"""
CONFIG/SETTINGS.PY - Lab 09: MCP SAP Incident Manager
======================================================
Central configuration for all MCP integrations.

SETUP INSTRUCTIONS:
1. Copy this to settings_local.py
2. Fill in your actual credentials
3. settings_local.py is gitignored
"""

import os
from dataclasses import dataclass
from typing import Optional

# =============================================================================
# GCP / VERTEX AI CONFIGURATION
# =============================================================================
GCP_PROJECT_ID = os.getenv("GOOGLE_CLOUD_PROJECT", "genai-2222026")
GCP_LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
MODEL_NAME = "gemini-2.0-flash"

# Your deployed RAG agent from Lab 06
RAG_AGENT_ID = "2708361571758768128"  # SAP Landscape Assistant

# =============================================================================
# SERVICENOW CONFIGURATION
# =============================================================================
@dataclass
class ServiceNowConfig:
    """ServiceNow PDI (Personal Developer Instance) configuration."""
    
    # Your instance URL (from developer.servicenow.com)
    # Format: https://devXXXXX.service-now.com
    instance_url: str = os.getenv("SERVICENOW_INSTANCE_URL", "https://dev374796.service-now.com")
    
    # Credentials
    username: str = os.getenv("SERVICENOW_USERNAME", "admin")
    password: str = os.getenv("SERVICENOW_PASSWORD", "Dh=Y0yy1sEC!")
    
    # API endpoints (standard ServiceNow REST API)
    @property
    def incident_api(self) -> str:
        return f"{self.instance_url}/api/now/table/incident"
    
    @property
    def change_api(self) -> str:
        return f"{self.instance_url}/api/now/table/change_request"
    
    @property
    def cmdb_api(self) -> str:
        return f"{self.instance_url}/api/now/table/cmdb_ci"
    
    # Default values for incident creation
    default_assignment_group: str = "SAP Basis Team"
    default_category: str = "SAP"
    default_subcategory: str = "Integration"

# =============================================================================
# MICROSOFT TEAMS CONFIGURATION
# =============================================================================
@dataclass
class TeamsConfig:
    """Microsoft Teams webhook configuration."""
    
    # Incoming Webhook URL for your Teams channel
    # Create at: Teams > Channel > Connectors > Incoming Webhook
    webhook_url: str = os.getenv("TEAMS_WEBHOOK_URL", "https://your-tenant.webhook.office.com/...")
    
    # Channel info (for display purposes)
    channel_name: str = "sap-incidents"
    team_name: str = "SAP Operations"

# =============================================================================
# MOCK MODE CONFIGURATION
# =============================================================================
@dataclass
class MockConfig:
    """Configuration for mock mode (when real APIs unavailable)."""
    
    # Set to True to use mock responses instead of real APIs
    use_mock_servicenow: bool = False  # ✅ LIVE MODE - Using real PDI!
    use_mock_teams: bool = True        # Change to False when you have webhook
    
    # Mock data paths
    mock_data_dir: str = "mock_data"

# =============================================================================
# GLOBAL CONFIG INSTANCES
# =============================================================================
servicenow_config = ServiceNowConfig()
teams_config = TeamsConfig()
mock_config = MockConfig()

# =============================================================================
# ENVIRONMENT VALIDATION
# =============================================================================
def validate_config() -> dict:
    """Validate configuration and return status."""
    status = {
        "servicenow": {
            "configured": servicenow_config.instance_url != "https://devXXXXX.service-now.com",
            "mock_mode": mock_config.use_mock_servicenow,
        },
        "teams": {
            "configured": "your-tenant" not in teams_config.webhook_url,
            "mock_mode": mock_config.use_mock_teams,
        },
        "gcp": {
            "project": GCP_PROJECT_ID,
            "region": GCP_LOCATION,
            "rag_agent": RAG_AGENT_ID,
        }
    }
    return status

if __name__ == "__main__":
    import json
    print("Configuration Status:")
    print(json.dumps(validate_config(), indent=2))
